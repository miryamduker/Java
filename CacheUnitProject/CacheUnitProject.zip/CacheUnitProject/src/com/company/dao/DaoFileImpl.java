package com.company.dao;

import com.company.dm.DataModel;
import com.google.gson.Gson;

import java.awt.font.TextHitInfo;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class DaoFileImpl<T> implements IDao<java.lang.Long, DataModel<T>>
{
    private java.lang.String filePath;
    private int capacity;
    private HashMap<Long, DataModel<T>> map;
    private ObjectOutputStream outputStream;


    /**
     * constructor
     * @param filePath of file
     * @param capacity of map
     */
    public DaoFileImpl(java.lang.String filePath, int capacity){
        this.filePath = new File("scr/"+filePath).getAbsolutePath();;
        this.capacity = capacity;
        map = new HashMap<Long, DataModel<T>>(capacity);
    }

    /**
     * constructor
     * @param filePath of file
     */
    public DaoFileImpl(java.lang.String filePath){
        this.filePath = new File("scr/"+filePath).getAbsolutePath();
        map = new HashMap<Long, DataModel<T>>();
    }

    /**
     * updates the file with new info
     * @param data to be inserted to file
     * @throws FileNotFoundException because we are assuming that the file exists
     */
    public void updateFile(HashMap<Long, DataModel<T>> data) {
        try {
            ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream(filePath));
            stream.writeObject(map);
            stream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * reads the file
     * @throws FileNotFoundException because we are assuming that the file exists
     */
    public void readFile() {
        try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream(filePath));
            map = (HashMap<Long, DataModel<T>>)stream.readObject();
            stream.close();

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**
     * save data
     * @param data to be saved
     */
    @Override
    public void save(DataModel<T> data) {
        readFile();
        map.put(data.getDataModelId(), data);
        updateFile(map);

    }

    /**
     * deletes data
     * @param data to be deleted
     */
    @Override
    public void delete(DataModel<T> data) {
        readFile();
        map.remove(data.getDataModelId());
        updateFile(map);
    }

    /**
     * finds data model by id
     * @param id to be found
     * @return the data model that was found
     */
    @Override
    public DataModel<T> find(java.lang.Long id) {
        readFile();
        return map.get(id) ;
    }

}
