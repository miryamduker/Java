package com.company.dao;

import java.io.FileNotFoundException;

public interface IDao <ID extends java.io.Serializable,T>{

    public void save(T entity) throws FileNotFoundException;

    public void delete(T entity);

    public T find(ID id);

}
