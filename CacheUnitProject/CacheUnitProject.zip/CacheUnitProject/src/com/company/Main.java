package com.company;

import com.company.dao.DaoFileImpl;
import com.company.dm.DataModel;

import java.io.FileNotFoundException;

public class Main {

    public static void main(String[] args) {
        DataModel<String> oo = new DataModel<String>(433L, "aaa");
        DataModel<String> oo1 = new DataModel<String>(420L, "bbb");


        DaoFileImpl<String> obj = new DaoFileImpl("src/com/company/resources/source",5);
        try {
            obj.save(oo);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        try {
            obj.save(oo1);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
